import pytest
import pandas as pd
from src.data_process import DrugBankProcessor, ChEMBLProcessor, MDProcessor

def test_drugbank_processor():
    processor = DrugBankProcessor()
    assert processor is not None

def test_chembl_processor():
    processor = ChEMBLProcessor()
    assert processor is not None

def test_md_processor():
    processor = MDProcessor()
    assert processor is not None

def test_data_loading():
    # 测试数据加载功能
    try:
        data = pd.read_csv('data/raw/drugbank.csv')
        assert len(data) > 0
    except FileNotFoundError:
        pytest.skip("Data file not found. Run data preparation first.") 