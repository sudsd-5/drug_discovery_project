# 保存为 E:\AI\drug_discovery_project\src\train_dti.py
import os
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import numpy as np
import yaml
import logging
from datetime import datetime
from torch.utils.tensorboard import SummaryWriter
from sklearn.metrics import roc_auc_score, precision_recall_curve, auc, accuracy_score
import matplotlib.pyplot as plt
import seaborn as sns
from dti_model import DTIHybridPredictor  # 仅导入 DTIHybridPredictor
from torch_geometric.loader import DataLoader as GeometricDataLoader
from sklearn.metrics import accuracy_score, roc_auc_score, average_precision_score
import warnings

# 忽略 torch_geometric 的警告
warnings.filterwarnings('ignore', category=UserWarning, module='torch_geometric.data.collate')

# 启用 cuDNN 优化
torch.backends.cudnn.enabled = True
torch.backends.cudnn.benchmark = True  # 自动选择最优算法

class DTIDataset(Dataset):
    """药物-靶点相互作用数据集"""
    def __init__(self, drug_graphs, target_embeddings, interactions, indices=None, device=None):
        if indices is not None:
            self.drug_graphs = [drug_graphs[i] for i in indices]
            self.target_embeddings = [target_embeddings[i].to(device) for i in indices]  # 预加载到 GPU
            self.interactions = interactions[indices].to(device)  # 预加载到 GPU
        else:
            self.drug_graphs = drug_graphs
            self.target_embeddings = [t.to(device) for t in target_embeddings]  # 预加载到 GPU
            self.interactions = interactions.to(device)  # 预加载到 GPU

    def __len__(self):
        return len(self.drug_graphs)

    def __getitem__(self, idx):
        drug = self.drug_graphs[idx]
        protein_embedding = self.target_embeddings[idx]
        interaction = self.interactions[idx]
        return drug, protein_embedding, interaction

def load_config(config_path='E:\\AI\\drug_discovery_project\\configs\\dti_config.yaml'):
    """加载配置文件"""
    with open(config_path, 'r', encoding='utf-8') as f:
        config = yaml.safe_load(f)
        print("Loaded config:", config)
        return config

def setup_logging(config):
    """设置日志记录"""
    log_dir = config['logging']['log_dir']
    models_dir = 'E:\\AI\\drug_discovery_project\\output\\models'
    tensorboard_dir = config['logging']['tensorboard_dir']
    output_log_dir = 'E:\\AI\\drug_discovery_project\\output'

    os.makedirs(log_dir, exist_ok=True)
    os.makedirs(models_dir, exist_ok=True)
    os.makedirs(tensorboard_dir, exist_ok=True)
    os.makedirs(output_log_dir, exist_ok=True)

    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    log_file = os.path.join(log_dir, f'dti_training_{timestamp}.log')
    output_log_file = os.path.join(output_log_dir, 'training.log')

    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s [%(levelname)s] %(message)s',
        handlers=[
            logging.FileHandler(log_file),
            logging.FileHandler(output_log_file),
            logging.StreamHandler()
        ]
    )

    return SummaryWriter(os.path.join(tensorboard_dir, timestamp))

def load_data(config, device):
    """加载数据并预加载到 GPU"""
    interactions_dir = config['data']['interactions_dir']

    drug_graphs_path = os.path.join(interactions_dir, 'drug_graphs.pt')
    drug_graphs = torch.load(drug_graphs_path, map_location=device)
    print(f"Number of graphs: {len(drug_graphs)}")

    target_embeddings_path = os.path.join(interactions_dir, 'target_embeddings.pt')
    target_embeddings = torch.load(target_embeddings_path, map_location=device)
    print(f"Number of target embeddings: {len(target_embeddings)}")

    interactions_path = os.path.join(interactions_dir, 'interactions.pt')
    interactions = torch.load(interactions_path, map_location=device)
    print(f"Number of interactions: {len(interactions)}")

    train_idx_path = os.path.join(interactions_dir, 'train_idx.pt')
    val_idx_path = os.path.join(interactions_dir, 'val_idx.pt')
    test_idx_path = os.path.join(interactions_dir, 'test_idx.pt')

    train_idx = torch.load(train_idx_path, map_location=device)
    val_idx = torch.load(val_idx_path, map_location=device)
    test_idx = torch.load(test_idx_path, map_location=device)

    return drug_graphs, target_embeddings, interactions, train_idx, val_idx, test_idx

def train_epoch(model, loader, criterion, optimizer, device):
    """训练一个 epoch"""
    model.train()
    total_loss = 0
    predictions = []
    labels = []
    for batch in loader:
        drug_graphs, target_embeddings, batch_labels = batch
        drug_graphs = drug_graphs.to(device)
        target_embeddings = target_embeddings.to(device)
        batch_labels = batch_labels.to(device).unsqueeze(1)

        optimizer.zero_grad()
        outputs = model(drug_graphs, target_embeddings)
        loss = criterion(outputs, batch_labels)
        loss.backward()
        optimizer.step()

        total_loss += loss.item()
        predictions.extend(torch.sigmoid(outputs).detach().cpu().numpy().flatten())
        labels.extend(batch_labels.detach().cpu().numpy().flatten())

    train_loss = total_loss / len(loader)
    labels = np.array(labels).astype(int)
    predictions = np.array(predictions)
    predictions_rounded = np.round(predictions).astype(int)
    train_acc = accuracy_score(labels, predictions_rounded)
    train_auroc = roc_auc_score(labels, predictions)
    train_auprc = average_precision_score(labels, predictions)
    return train_loss, train_acc, train_auroc, train_auprc

def validate(model, val_loader, criterion, device):
    """验证模型"""
    model.eval()
    total_loss = 0
    all_labels = []
    all_preds = []

    with torch.no_grad():
        for batch in val_loader:
            drug_data, protein_data, labels = batch
            drug_data = drug_data.to(device)
            protein_data = protein_data.to(device)
            labels = labels.to(device)

            outputs = model(drug_data, protein_data)
            labels = labels.unsqueeze(1)
            loss = criterion(outputs, labels)

            total_loss += loss.item()
            all_labels.append(labels.cpu())
            all_preds.append(outputs.cpu())

    val_loss = total_loss / len(val_loader)
    all_labels = torch.cat(all_labels)
    all_preds = torch.cat(all_preds)

    all_labels = all_labels.squeeze().numpy()
    all_labels = all_labels.astype(int)
    all_preds_proba = torch.sigmoid(all_preds).squeeze().numpy()
    all_preds_binary = (all_preds_proba > 0.5).astype(int)

    val_acc = accuracy_score(all_labels, all_preds_binary)
    val_auroc = roc_auc_score(all_labels, all_preds_proba)
    val_auprc = average_precision_score(all_labels, all_preds_proba)

    return val_loss, val_acc, val_auroc, val_auprc

def plot_training_results(train_metrics, val_metrics, save_dir, results_dir, model_name, fold=None):
    """绘制训练结果图并保存到指定目录"""
    os.makedirs(save_dir, exist_ok=True)
    os.makedirs(results_dir, exist_ok=True)

    suffix = f'_fold{fold}' if fold is not None else ''
    
    plt.figure(figsize=(10, 6))
    plt.plot(train_metrics['loss'], label='Training Loss')
    plt.plot(val_metrics['loss'], label='Validation Loss')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.title(f'{model_name} - Training and Validation Loss{suffix}')
    plt.legend()
    plt.savefig(os.path.join(results_dir, f'{model_name}_loss_curve{suffix}.png'))
    plt.close()

    plt.figure(figsize=(10, 6))
    plt.plot(train_metrics['accuracy'], label='Training Accuracy')
    plt.plot(val_metrics['accuracy'], label='Validation Accuracy')
    plt.xlabel('Epoch')
    plt.ylabel('Accuracy')
    plt.title(f'{model_name} - Training and Validation Accuracy{suffix}')
    plt.legend()
    plt.savefig(os.path.join(results_dir, f'{model_name}_accuracy_curve{suffix}.png'))
    plt.close()

    plt.figure(figsize=(10, 6))
    plt.plot(train_metrics['auroc'], label='Training AUROC')
    plt.plot(val_metrics['auroc'], label='Validation AUROC')
    plt.xlabel('Epoch')
    plt.ylabel('AUROC')
    plt.title(f'{model_name} - Training and Validation AUROC{suffix}')
    plt.legend()
    plt.savefig(os.path.join(results_dir, f'{model_name}_auroc_curve{suffix}.png'))
    plt.close()

    plt.figure(figsize=(10, 6))
    plt.plot(train_metrics['auprc'], label='Training AUPRC')
    plt.plot(val_metrics['auprc'], label='Validation AUPRC')
    plt.xlabel('Epoch')
    plt.ylabel('AUPRC')
    plt.title(f'{model_name} - Training and Validation AUPRC{suffix}')
    plt.legend()
    plt.savefig(os.path.join(results_dir, f'{model_name}_auprc_curve{suffix}.png'))
    plt.close()

def train_model(model, model_name, train_loader, val_loader, test_loader, config, device, writer, fold=None):
    """训练单个模型（支持交叉验证）"""
    criterion = torch.nn.BCEWithLogitsLoss(pos_weight=torch.tensor([1.4]).to(device))  # 调整 pos_weight
    optimizer = optim.AdamW(
        model.parameters(),
        lr=config['training']['learning_rate'],
        weight_decay=config['training']['weight_decay'],
        fused=True if torch.cuda.is_available() else False
    )

    scheduler = optim.lr_scheduler.ReduceLROnPlateau(
        optimizer,
        mode='min',
        factor=config['scheduler']['factor'],
        patience=config['scheduler']['patience'],
        min_lr=config['scheduler']['min_lr']
    )

    epochs = config['training']['epochs']
    early_stopping_patience = config['training']['early_stopping_patience']
    early_stopping_counter = 0
    best_val_auprc = 0

    train_metrics = {'loss': [], 'accuracy': [], 'auroc': [], 'auprc': []}
    val_metrics = {'loss': [], 'accuracy': [], 'auroc': [], 'auprc': []}

    for epoch in range(epochs):
        train_loss, train_acc, train_auroc, train_auprc = train_epoch(model, train_loader, criterion, optimizer, device)
        val_loss, val_acc, val_auroc, val_auprc = validate(model, val_loader, criterion, device)

        scheduler.step(val_loss)

        train_metrics['loss'].append(train_loss)
        train_metrics['accuracy'].append(train_acc)
        train_metrics['auroc'].append(train_auroc)
        train_metrics['auprc'].append(train_auprc)

        val_metrics['loss'].append(val_loss)
        val_metrics['accuracy'].append(val_acc)
        val_metrics['auroc'].append(val_auroc)
        val_metrics['auprc'].append(val_auprc)

        # 移除 fold 参数，因为不再使用交叉验证
        writer.add_scalar(f'Loss/train_{model_name}', train_loss, epoch)
        writer.add_scalar(f'Loss/val_{model_name}', val_loss, epoch)
        writer.add_scalar(f'Accuracy/train_{model_name}', train_acc, epoch)
        writer.add_scalar(f'Accuracy/val_{model_name}', val_acc, epoch)
        writer.add_scalar(f'AUROC/train_{model_name}', train_auroc, epoch)
        writer.add_scalar(f'AUROC/val_{model_name}', val_auroc, epoch)
        writer.add_scalar(f'AUPRC/train_{model_name}', train_auprc, epoch)
        writer.add_scalar(f'AUPRC/val_{model_name}', val_auprc, epoch)

        logging.info(f'{model_name} - Epoch {epoch + 1}/{epochs}:')
        logging.info(
            f'Train Loss: {train_loss:.4f}, Train Acc: {train_acc:.4f}, Train AUROC: {train_auroc:.4f}, Train AUPRC: {train_auprc:.4f}')
        logging.info(
            f'Val Loss: {val_loss:.4f}, Val Acc: {val_acc:.4f}, Val AUROC: {val_auroc:.4f}, Val AUPRC: {val_auprc:.4f}')
        logging.info('------')

        if val_auprc > best_val_auprc:
            best_val_auprc = val_auprc
            torch.save(model.state_dict(), os.path.join('E:\\AI\\drug_discovery_project\\output\\models', f'best_model_{model_name}.pt'))
            early_stopping_counter = 0
        else:
            early_stopping_counter += 1

        if early_stopping_counter >= early_stopping_patience:
            logging.info(f'{model_name} - Early stopping at epoch {epoch + 1}')
            break

    results_dir = 'E:\\AI\\drug_discovery_project\\output\\results'
    plot_training_results(train_metrics, val_metrics, 'E:\\AI\\drug_discovery_project\\output\\models', results_dir, model_name)

    model.load_state_dict(torch.load(os.path.join('E:\\AI\\drug_discovery_project\\output\\models', f'best_model_{model_name}.pt')))
    test_loss, test_acc, test_auroc, test_auprc = validate(model, test_loader, criterion, device)

    logging.info(f'{model_name} - Test results:')
    logging.info(f'Loss: {test_loss:.4f}, Accuracy: {test_acc:.4f}, AUROC: {test_auroc:.4f}, AUPRC: {test_auprc:.4f}')

    return test_auprc, test_acc

def main():
    """主函数：使用固定的训练-验证-测试划分训练 DTI Hybrid Predictor"""
    config = load_config()
    writer = setup_logging(config)

    device = torch.device(config['hardware']['device'] if torch.cuda.is_available() else 'cpu')
    logging.info(f"Using device: {device}")

    # 加载数据并预加载到 GPU
    drug_graphs, target_embeddings, interactions, train_idx, val_idx, test_idx = load_data(config, device)

    # 创建训练、验证和测试数据集
    batch_size = config['training']['batch_size']
    train_dataset = DTIDataset(drug_graphs, target_embeddings, interactions, train_idx, device=device)
    val_dataset = DTIDataset(drug_graphs, target_embeddings, interactions, val_idx, device=device)
    test_dataset = DTIDataset(drug_graphs, target_embeddings, interactions, test_idx, device=device)

    train_loader = GeometricDataLoader(
        train_dataset,
        batch_size=batch_size,
        shuffle=True,
        num_workers=0,
        pin_memory=False
    )
    val_loader = GeometricDataLoader(
        val_dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=0,
        pin_memory=False
    )
    test_loader = GeometricDataLoader(
        test_dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=0,
        pin_memory=False
    )

    # 初始化模型
    hybrid_model = DTIHybridPredictor(config['model']).to(device)
    logging.info("Training Hybrid Model (DTIHybridPredictor)...")
    test_auprc, test_acc = train_model(hybrid_model, "HybridModel", train_loader, val_loader, test_loader, config, device, writer)

    # 直接输出测试结果
    logging.info("Final Results:")
    logging.info(f"Test AUPRC: {test_auprc:.4f}")
    logging.info(f"Test Accuracy: {test_acc:.4f}")

    writer.close()

if __name__ == "__main__":
    main()