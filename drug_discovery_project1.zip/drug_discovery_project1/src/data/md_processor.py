import os
import numpy as np
import pandas as pd
from rdkit import Chem
from rdkit.Chem import AllChem
from tqdm import tqdm
import torch
from torch_geometric.data import Data
import MDAnalysis as mda
from MDAnalysis.analysis import rms, contacts

class MDProcessor:
    def __init__(self, data_dir):
        self.data_dir = data_dir
        self.raw_dir = os.path.join(data_dir, "raw", "md")
        self.processed_dir = os.path.join(data_dir, "processed", "md_features")
        
    def prepare_md_input(self, mol, output_dir):
        """准备MD模拟输入文件"""
        # 创建输出目录
        os.makedirs(output_dir, exist_ok=True)
        
        # 保存PDB文件
        pdb_path = os.path.join(output_dir, "molecule.pdb")
        Chem.PDBWriter(pdb_path).write(mol)
        
        # 生成GROMACS拓扑文件
        # 这里需要根据实际的GROMACS设置进行调整
        return pdb_path
    
    def run_md_simulation(self, pdb_path, output_dir, simulation_time=10):
        """运行MD模拟"""
        # 这里需要根据实际的GROMACS命令进行调整
        # 示例命令：
        # gmx grompp -f md.mdp -c molecule.pdb -p topol.top -o md.tpr
        # gmx mdrun -v -deffnm md
        pass
    
    def extract_md_features(self, trajectory_path):
        """从MD轨迹中提取特征"""
        # 加载轨迹
        u = mda.Universe(trajectory_path)
        
        # 计算RMSD
        rmsd_analyzer = rms.RMSD(u, select='all')
        rmsd_analyzer.run()
        rmsd_values = rmsd_analyzer.rmsd[:, 2]  # 获取RMSD值
        
        # 计算接触图
        contact_analyzer = contacts.Contacts(u, select='all')
        contact_analyzer.run()
        contact_maps = contact_analyzer.contact_map
        
        # 计算其他特征
        # 1. 二级结构含量
        # 2. 溶剂可及表面积
        # 3. 氢键网络
        # 4. 能量项
        
        return {
            'rmsd': rmsd_values,
            'contact_maps': contact_maps,
            # 添加其他特征
        }
    
    def create_md_graph_data(self, mol, md_features, label):
        """创建包含MD特征的图数据"""
        # 获取分子图特征
        atom_features = []
        for atom in mol.GetAtoms():
            features = [
                atom.GetAtomicNum(),
                atom.GetDegree(),
                atom.GetFormalCharge(),
                atom.GetNumRadicalElectrons(),
                atom.GetHybridization(),
                atom.GetIsAromatic(),
                atom.GetTotalNumHs()
            ]
            atom_features.append(features)
        x = torch.tensor(atom_features, dtype=torch.float)
        
        # 获取边特征和边索引
        edge_features = []
        edge_index = []
        for bond in mol.GetBonds():
            i = bond.GetBeginAtomIdx()
            j = bond.GetEndAtomIdx()
            edge_index.append([i, j])
            edge_index.append([j, i])
            features = [
                bond.GetBondType(),
                bond.GetIsConjugated(),
                bond.IsInRing(),
                bond.GetStereo()
            ]
            edge_features.append(features)
            edge_features.append(features)
        edge_index = torch.tensor(edge_index, dtype=torch.long).t().contiguous()
        edge_attr = torch.tensor(edge_features, dtype=torch.float)
        
        # 添加MD特征
        md_data = torch.tensor(md_features['rmsd'], dtype=torch.float)
        
        # 创建图数据
        data = Data(
            x=x,
            edge_index=edge_index,
            edge_attr=edge_attr,
            md_data=md_data,  # 添加MD数据
            y=torch.tensor([label], dtype=torch.float)
        )
        
        return data
    
    def process_molecule(self, smiles, label, output_dir):
        """处理单个分子"""
        # 处理SMILES
        mol = Chem.MolFromSmiles(smiles)
        if mol is None:
            return None
        
        # 添加氢原子并生成3D构象
        mol = Chem.AddHs(mol)
        AllChem.EmbedMolecule(mol, randomSeed=42)
        AllChem.MMFFOptimizeMolecule(mol)
        
        # 准备MD输入
        pdb_path = self.prepare_md_input(mol, output_dir)
        
        # 运行MD模拟
        self.run_md_simulation(pdb_path, output_dir)
        
        # 提取MD特征
        trajectory_path = os.path.join(output_dir, "md.xtc")
        md_features = self.extract_md_features(trajectory_path)
        
        # 创建图数据
        data = self.create_md_graph_data(mol, md_features, label)
        
        return data
    
    def process_data(self, smiles_list, labels):
        """处理所有分子"""
        print("开始处理MD数据...")
        
        # 创建处理后的数据目录
        os.makedirs(self.processed_dir, exist_ok=True)
        
        # 处理每个分子
        processed_data = []
        for idx, (smiles, label) in enumerate(tqdm(zip(smiles_list, labels))):
            # 为每个分子创建输出目录
            output_dir = os.path.join(self.raw_dir, f"molecule_{idx}")
            
            # 处理分子
            data = self.process_molecule(smiles, label, output_dir)
            if data is not None:
                processed_data.append(data)
        
        # 保存处理后的数据
        torch.save(processed_data, os.path.join(self.processed_dir, "md_processed.pt"))
        print(f"处理完成，共保存 {len(processed_data)} 个分子图")

if __name__ == "__main__":
    # 测试MD数据处理
    data_dir = "data"
    
    # 示例数据
    smiles_list = [
        "CC(=O)OC1=CC=CC=C1C(=O)O",
        "CC12CCC3C(C1CCC2O)CCC4=CC(=O)CCC34C"
    ]
    labels = [0.5, 0.8]
    
    # 处理MD数据
    md_processor = MDProcessor(data_dir)
    md_processor.process_data(smiles_list, labels) 