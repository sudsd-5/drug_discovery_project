import os
import pandas as pd
import numpy as np
from rdkit import Chem
from rdkit.Chem import AllChem
from tqdm import tqdm
import torch
from torch_geometric.data import Data, Dataset

class DrugBankPreprocessor:
    def __init__(self, data_dir):
        self.data_dir = data_dir
        self.raw_dir = os.path.join(data_dir, "raw", "drugbank")
        self.processed_dir = os.path.join(data_dir, "processed")
        
    def load_raw_data(self):
        """加载DrugBank原始数据"""
        # 这里需要根据实际的DrugBank数据格式进行调整
        drug_target_file = os.path.join(self.raw_dir, "drug_target_interactions.csv")
        df = pd.read_csv(drug_target_file)
        return df
    
    def process_smiles(self, smiles):
        """处理SMILES字符串，生成3D构象"""
        mol = Chem.MolFromSmiles(smiles)
        if mol is None:
            return None
        
        # 添加氢原子
        mol = Chem.AddHs(mol)
        
        # 生成3D构象
        AllChem.EmbedMolecule(mol, randomSeed=42)
        AllChem.MMFFOptimizeMolecule(mol)
        
        return mol
    
    def get_atom_features(self, atom):
        """获取原子特征"""
        features = [
            atom.GetAtomicNum(),  # 原子序数
            atom.GetDegree(),     # 原子度数
            atom.GetFormalCharge(),  # 形式电荷
            atom.GetNumRadicalElectrons(),  # 自由基电子数
            atom.GetHybridization(),  # 杂化类型
            atom.GetIsAromatic(),  # 是否芳香
            atom.GetTotalNumHs()   # 氢原子数
        ]
        return features
    
    def get_bond_features(self, bond):
        """获取键特征"""
        features = [
            bond.GetBondType(),  # 键类型
            bond.GetIsConjugated(),  # 是否共轭
            bond.IsInRing(),  # 是否在环中
            bond.GetStereo()  # 立体化学
        ]
        return features
    
    def create_graph_data(self, mol, label):
        """创建图数据"""
        if mol is None:
            return None
            
        # 获取原子特征
        atom_features = []
        for atom in mol.GetAtoms():
            features = self.get_atom_features(atom)
            atom_features.append(features)
        x = torch.tensor(atom_features, dtype=torch.float)
        
        # 获取边特征和边索引
        edge_features = []
        edge_index = []
        for bond in mol.GetBonds():
            i = bond.GetBeginAtomIdx()
            j = bond.GetEndAtomIdx()
            edge_index.append([i, j])
            edge_index.append([j, i])  # 添加反向边
            features = self.get_bond_features(bond)
            edge_features.append(features)
            edge_features.append(features)  # 添加反向边的特征
        edge_index = torch.tensor(edge_index, dtype=torch.long).t().contiguous()
        edge_attr = torch.tensor(edge_features, dtype=torch.float)
        
        # 创建图数据
        data = Data(
            x=x,
            edge_index=edge_index,
            edge_attr=edge_attr,
            y=torch.tensor([label], dtype=torch.float)
        )
        
        return data
    
    def process_data(self):
        """处理所有数据"""
        print("开始处理DrugBank数据...")
        
        # 加载原始数据
        df = self.load_raw_data()
        
        # 创建处理后的数据目录
        os.makedirs(self.processed_dir, exist_ok=True)
        
        # 处理每个分子
        processed_data = []
        for idx, row in tqdm(df.iterrows(), total=len(df)):
            smiles = row['smiles']
            label = row['label']
            
            # 处理SMILES
            mol = self.process_smiles(smiles)
            if mol is None:
                continue
                
            # 创建图数据
            data = self.create_graph_data(mol, label)
            if data is not None:
                processed_data.append(data)
        
        # 保存处理后的数据
        torch.save(processed_data, os.path.join(self.processed_dir, "drugbank_processed.pt"))
        print(f"处理完成，共保存 {len(processed_data)} 个分子图")

class ChEMBLPreprocessor:
    def __init__(self, data_dir):
        self.data_dir = data_dir
        self.raw_dir = os.path.join(data_dir, "raw", "chembl")
        self.processed_dir = os.path.join(data_dir, "processed")
        
    def load_raw_data(self):
        """加载ChEMBL原始数据"""
        # 这里需要根据实际的ChEMBL数据格式进行调整
        property_file = os.path.join(self.raw_dir, "molecular_properties.csv")
        df = pd.read_csv(property_file)
        return df
    
    def process_data(self):
        """处理ChEMBL数据"""
        print("开始处理ChEMBL数据...")
        
        # 加载原始数据
        df = self.load_raw_data()
        
        # 创建处理后的数据目录
        os.makedirs(self.processed_dir, exist_ok=True)
        
        # 使用DrugBankPreprocessor中的方法处理分子
        preprocessor = DrugBankPreprocessor(self.data_dir)
        
        # 处理每个分子
        processed_data = []
        for idx, row in tqdm(df.iterrows(), total=len(df)):
            smiles = row['smiles']
            property_value = row['property_value']
            
            # 处理SMILES
            mol = preprocessor.process_smiles(smiles)
            if mol is None:
                continue
                
            # 创建图数据
            data = preprocessor.create_graph_data(mol, property_value)
            if data is not None:
                processed_data.append(data)
        
        # 保存处理后的数据
        torch.save(processed_data, os.path.join(self.processed_dir, "chembl_processed.pt"))
        print(f"处理完成，共保存 {len(processed_data)} 个分子图")

if __name__ == "__main__":
    # 测试数据预处理
    data_dir = "data"
    
    # 处理DrugBank数据
    drugbank_processor = DrugBankPreprocessor(data_dir)
    drugbank_processor.process_data()
    
    # 处理ChEMBL数据
    chembl_processor = ChEMBLPreprocessor(data_dir)
    chembl_processor.process_data() 