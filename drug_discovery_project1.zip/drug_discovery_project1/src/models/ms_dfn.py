import torch
import torch.nn.functional as F
from torch_geometric.nn import GCNConv, global_mean_pool, global_max_pool

class MultiScaleDFN(torch.nn.Module):
    def __init__(self, input_dim=3, hidden_dim=64):
        super(MultiScaleDFN, self).__init__()
        # 不同尺度的GNN层
        self.conv1 = GCNConv(input_dim, hidden_dim)  # 局部尺度
        self.conv2 = GCNConv(hidden_dim, hidden_dim)  # 中等尺度
        self.conv3 = GCNConv(hidden_dim, hidden_dim)  # 全局尺度
        
        # 特征融合层
        self.fusion = torch.nn.Sequential(
            torch.nn.Linear(hidden_dim * 3, hidden_dim),
            torch.nn.ReLU(),
            torch.nn.Linear(hidden_dim, hidden_dim)
        )
        
    def forward(self, data):
        x, edge_index, batch = data.x, data.edge_index, data.batch
        
        # 局部尺度特征
        x1 = F.relu(self.conv1(x, edge_index))
        x1 = global_mean_pool(x1, batch)
        
        # 中等尺度特征
        x2 = F.relu(self.conv2(x1, edge_index))
        x2 = global_mean_pool(x2, batch)
        
        # 全局尺度特征
        x3 = F.relu(self.conv3(x2, edge_index))
        x3 = global_max_pool(x3, batch)  # 使用最大池化捕获全局信息
        
        # 特征融合
        combined = torch.cat([x1, x2, x3], dim=1)
        output = self.fusion(combined)
        
        return output

if __name__ == "__main__":
    # 测试模块
    model = MultiScaleDFN()
    print(model) 