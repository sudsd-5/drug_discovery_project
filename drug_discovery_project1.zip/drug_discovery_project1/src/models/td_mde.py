import torch
import torch.nn.functional as F
from torch_geometric.nn import GCNConv, global_mean_pool
import numpy as np

class TimeSeriesEncoder(torch.nn.Module):
    def __init__(self, input_dim, hidden_dim):
        super(TimeSeriesEncoder, self).__init__()
        self.lstm = torch.nn.LSTM(
            input_size=input_dim,
            hidden_size=hidden_dim,
            num_layers=2,
            batch_first=True
        )
        
    def forward(self, x):
        # x shape: (batch_size, seq_len, input_dim)
        output, (hidden, cell) = self.lstm(x)
        return hidden[-1]  # 使用最后一层的隐藏状态

class TDMDE(torch.nn.Module):
    def __init__(self, input_dim=3, hidden_dim=64, md_dim=10):
        super(TDMDE, self).__init__()
        # MD特征编码器
        self.md_encoder = TimeSeriesEncoder(md_dim, hidden_dim)
        
        # 分子图编码器
        self.conv1 = GCNConv(input_dim, hidden_dim)
        self.conv2 = GCNConv(hidden_dim, hidden_dim)
        
        # 特征融合
        self.fusion = torch.nn.Sequential(
            torch.nn.Linear(hidden_dim * 2, hidden_dim),
            torch.nn.ReLU(),
            torch.nn.Linear(hidden_dim, hidden_dim)
        )
        
    def process_md_data(self, md_data):
        # 处理MD数据，提取时间序列特征
        # md_data shape: (batch_size, seq_len, md_dim)
        return self.md_encoder(md_data)
        
    def forward(self, data):
        x, edge_index, batch = data.x, data.edge_index, data.batch
        
        # 分子图特征
        graph_features = F.relu(self.conv1(x, edge_index))
        graph_features = F.relu(self.conv2(graph_features, edge_index))
        graph_features = global_mean_pool(graph_features, batch)
        
        # MD特征
        if hasattr(data, 'md_data'):
            md_features = self.process_md_data(data.md_data)
        else:
            # 如果没有MD数据，使用零向量
            md_features = torch.zeros(graph_features.size(0), graph_features.size(1))
            if graph_features.is_cuda:
                md_features = md_features.cuda()
        
        # 特征融合
        combined = torch.cat([graph_features, md_features], dim=1)
        output = self.fusion(combined)
        
        return output

if __name__ == "__main__":
    # 测试模块
    model = TDMDE()
    print(model) 