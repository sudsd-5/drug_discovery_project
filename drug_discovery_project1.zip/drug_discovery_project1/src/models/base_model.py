import torch
import torch.nn.functional as F
from torch_geometric.nn import GCNConv, global_mean_pool

class DrugDiscoveryGNN(torch.nn.Module):
    def __init__(self, input_dim=3, hidden_dim=64, output_dim=1):
        super(DrugDiscoveryGNN, self).__init__()
        self.conv1 = GCNConv(input_dim, hidden_dim)
        self.conv2 = GCNConv(hidden_dim, hidden_dim)
        self.fc1 = torch.nn.Linear(hidden_dim, hidden_dim // 2)
        self.fc2 = torch.nn.Linear(hidden_dim // 2, output_dim)

    def forward(self, data):
        x, edge_index, batch = data.x, data.edge_index, data.batch
        x = F.relu(self.conv1(x, edge_index))
        x = F.relu(self.conv2(x, edge_index))
        x = global_mean_pool(x, batch)  # 图级池化
        x = F.relu(self.fc1(x))
        x = torch.sigmoid(self.fc2(x))
        return x

class DrugDiscoveryModel(torch.nn.Module):
    def __init__(self, input_dim=3, hidden_dim=64, output_dim=1):
        super(DrugDiscoveryModel, self).__init__()
        # 基础GNN层
        self.base_gnn = DrugDiscoveryGNN(input_dim, hidden_dim, hidden_dim)
        
        # 创新模块
        self.ms_dfn = None  # 多尺度特征融合模块
        self.amse = None    # 子结构增强模块
        self.td_mde = None  # MD嵌入模块
        
        # 输出层
        self.output_layer = torch.nn.Linear(hidden_dim * 4, output_dim)  # 4 = 基础特征 + 3个创新模块
        
    def forward(self, data):
        # 基础特征提取
        base_features = self.base_gnn(data)
        
        # 创新模块特征
        ms_features = self.ms_dfn(data) if self.ms_dfn is not None else torch.zeros_like(base_features)
        amse_features = self.amse(data) if self.amse is not None else torch.zeros_like(base_features)
        md_features = self.td_mde(data) if self.td_mde is not None else torch.zeros_like(base_features)
        
        # 特征融合
        combined_features = torch.cat([base_features, ms_features, amse_features, md_features], dim=1)
        
        # 输出预测
        output = torch.sigmoid(self.output_layer(combined_features))
        return output

if __name__ == "__main__":
    # 测试模型
    model = DrugDiscoveryModel()
    print(model) 