import torch
import torch.nn.functional as F
from torch_geometric.nn import GCNConv, global_mean_pool
from torch_geometric.utils import subgraph

class SubstructureAttention(torch.nn.Module):
    def __init__(self, hidden_dim):
        super(SubstructureAttention, self).__init__()
        self.attention = torch.nn.Sequential(
            torch.nn.Linear(hidden_dim, hidden_dim // 2),
            torch.nn.ReLU(),
            torch.nn.Linear(hidden_dim // 2, 1)
        )
        
    def forward(self, x):
        attention_weights = torch.sigmoid(self.attention(x))
        return attention_weights

class AMSE(torch.nn.Module):
    def __init__(self, input_dim=3, hidden_dim=64):
        super(AMSE, self).__init__()
        # 子结构特征提取
        self.conv1 = GCNConv(input_dim, hidden_dim)
        self.conv2 = GCNConv(hidden_dim, hidden_dim)
        
        # 注意力机制
        self.attention = SubstructureAttention(hidden_dim)
        
        # 特征融合
        self.fusion = torch.nn.Sequential(
            torch.nn.Linear(hidden_dim * 2, hidden_dim),
            torch.nn.ReLU(),
            torch.nn.Linear(hidden_dim, hidden_dim)
        )
        
    def extract_substructure(self, x, edge_index, k_hop=2):
        # 提取k-hop子结构
        sub_x, sub_edge_index = subgraph(
            edge_index,
            num_nodes=x.size(0),
            relabel_nodes=True
        )
        return sub_x, sub_edge_index
        
    def forward(self, data):
        x, edge_index, batch = data.x, data.edge_index, data.batch
        
        # 提取子结构
        sub_x, sub_edge_index = self.extract_substructure(x, edge_index)
        
        # 子结构特征
        sub_features = F.relu(self.conv1(sub_x, sub_edge_index))
        sub_features = F.relu(self.conv2(sub_features, sub_edge_index))
        
        # 全局特征
        global_features = F.relu(self.conv1(x, edge_index))
        global_features = F.relu(self.conv2(global_features, edge_index))
        
        # 注意力权重
        attention_weights = self.attention(sub_features)
        
        # 加权特征
        weighted_sub_features = sub_features * attention_weights
        
        # 特征融合
        combined = torch.cat([weighted_sub_features, global_features], dim=1)
        output = self.fusion(combined)
        
        return output

if __name__ == "__main__":
    # 测试模块
    model = AMSE()
    print(model) 