"""
Drug Discovery Project
A comprehensive project for drug discovery using deep learning and molecular dynamics.
"""

from . import data
from . import models
from . import training
from . import evaluation

__version__ = '0.1.0' 