# 保存为 E:\AI\drug_discovery_project\src\dti_model.py
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import GATConv, global_mean_pool
from torch_geometric.data import Data, Batch
from torch.nn import TransformerEncoder, TransformerEncoderLayer

class DrugEncoder(nn.Module):
    """药物编码器，使用图注意力网络（GAT）提取药物分子的特征"""
    def __init__(self, input_dim=15, hidden_channels=64, output_channels=64, num_layers=3, dropout=0.4,
                 conv_type='GAT'):
        super(DrugEncoder, self).__init__()

        self.num_layers = num_layers
        self.dropout = dropout
        self.conv_type = conv_type

        self.convs = nn.ModuleList()
        self.batch_norms = nn.ModuleList()

        # 第一层 GAT
        if conv_type == 'GAT':
            self.convs.append(GATConv(input_dim, hidden_channels))
        else:
            raise ValueError(f"不支持的卷积类型: {conv_type}")

        self.batch_norms.append(nn.BatchNorm1d(hidden_channels))

        # 中间层 GAT
        for _ in range(num_layers - 2):
            if conv_type == 'GAT':
                self.convs.append(GATConv(hidden_channels, hidden_channels))
            self.batch_norms.append(nn.BatchNorm1d(hidden_channels))

        # 最后一层 GAT
        if conv_type == 'GAT':
            self.convs.append(GATConv(hidden_channels, output_channels))
        self.batch_norms.append(nn.BatchNorm1d(output_channels))

        self.dropout_layer = nn.Dropout(p=dropout)

    def forward(self, x, edge_index, batch):
        for i in range(self.num_layers):
            x = self.convs[i](x, edge_index)
            x = self.batch_norms[i](x)
            x = F.relu(x)
            x = self.dropout_layer(x)

        # 全局池化，得到图级表示
        x = global_mean_pool(x, batch)
        return x

class ProteinEncoder(nn.Module):
    """蛋白质编码器，使用预计算的 ESM-2 嵌入并通过全连接层投影"""
    def __init__(self, input_dim=480, output_channels=64, dropout=0.4):
        super(ProteinEncoder, self).__init__()
        self.fc = nn.Linear(input_dim, output_channels)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x):
        x = self.fc(x)
        x = F.relu(x)
        x = self.dropout(x)
        return x

class ComplexLinear(nn.Module):
    """复数全连接层，处理复数输入（实部和虚部）"""
    def __init__(self, in_features, out_features):
        super(ComplexLinear, self).__init__()
        self.real_weight = nn.Parameter(torch.randn(out_features, in_features))
        self.imag_weight = nn.Parameter(torch.randn(out_features, in_features))
        self.real_bias = nn.Parameter(torch.randn(out_features))
        self.imag_bias = nn.Parameter(torch.randn(out_features))

    def forward(self, x):
        real_x = x[:, :, 0]
        imag_x = x[:, :, 1]
        real_out = (torch.matmul(real_x, self.real_weight.t()) - 
                    torch.matmul(imag_x, self.imag_weight.t()) + 
                    self.real_bias)
        imag_out = (torch.matmul(real_x, self.imag_weight.t()) + 
                    torch.matmul(imag_x, self.real_weight.t()) + 
                    self.imag_bias)
        return torch.stack([real_out, imag_out], dim=-1)

class ComplexActivation(nn.Module):
    """复数激活函数，基于复数模长和相位的非线性变换"""
    def forward(self, x):
        real = x[:, :, 0]
        imag = x[:, :, 1]
        magnitude = torch.sqrt(real**2 + imag**2 + 1e-8)
        magnitude = torch.relu(magnitude)
        phase = torch.atan2(imag, real)
        real_out = magnitude * torch.cos(phase)
        imag_out = magnitude * torch.sin(phase)
        return torch.stack([real_out, imag_out], dim=-1)

class DTIHybridPredictor(nn.Module):
    """药物-靶点相互作用预测模型（虚数-实数特征融合）"""
    def __init__(self, config):
        super(DTIHybridPredictor, self).__init__()

        # 从 config 中获取超参数
        drug_input_dim = config.get('drug_input_dim', 15)
        drug_hidden_channels = config.get('drug_hidden_channels', 64)
        drug_output_channels = config.get('drug_output_channels', 64)
        drug_num_layers = config.get('drug_num_layers', 3)
        drug_dropout = config.get('drug_dropout', 0.4)
        drug_conv_type = config.get('drug_conv_type', 'GAT')

        protein_input_dim = config.get('protein_input_dim', 480)
        protein_output_channels = config.get('protein_output_channels', 64)
        protein_dropout = config.get('protein_dropout', 0.4)

        transformer_d_model = config.get('transformer_d_model', 64)
        transformer_nhead = config.get('transformer_nhead', 4)
        transformer_num_layers = config.get('transformer_num_layers', 1)
        transformer_dropout = config.get('transformer_dropout', 0.4)

        # 药物编码器
        self.drug_encoder = DrugEncoder(
            input_dim=drug_input_dim,
            hidden_channels=drug_hidden_channels,
            output_channels=drug_output_channels,
            num_layers=drug_num_layers,
            dropout=drug_dropout,
            conv_type=drug_conv_type
        )

        # 蛋白编码器
        self.protein_encoder = ProteinEncoder(
            input_dim=protein_input_dim,
            output_channels=protein_output_channels,
            dropout=protein_dropout
        )

        # 投影层：将药物和蛋白特征投影到 Transformer 输入维度
        self.drug_projection = nn.Linear(drug_output_channels, transformer_d_model)
        self.protein_projection = nn.Linear(protein_output_channels, transformer_d_model)

        # Transformer 层（实数分支）
        transformer_layer = TransformerEncoderLayer(
            d_model=transformer_d_model,
            nhead=transformer_nhead,
            dropout=transformer_dropout,
            batch_first=True
        )
        self.transformer = TransformerEncoder(
            transformer_layer,
            num_layers=transformer_num_layers
        )

        # 虚数分支：三层复数全连接层
        self.complex_branch1 = ComplexLinear(transformer_d_model, transformer_d_model)
        self.complex_branch2 = ComplexLinear(transformer_d_model, transformer_d_model)
        self.complex_branch3 = ComplexLinear(transformer_d_model, transformer_d_model)
        self.complex_act = ComplexActivation()

        # 注意力机制：用于虚实特征融合
        self.attention = nn.MultiheadAttention(embed_dim=transformer_d_model, num_heads=4)
        # 投影层：将 real_features 和 complex_magnitude 的维度从 transformer_d_model * 2 降到 transformer_d_model
        self.attention_projection = nn.Linear(transformer_d_model * 2, transformer_d_model)

        # 融合层
        combined_dim = transformer_d_model * 2  # Transformer 输出维度 * 序列长度（2）
        self.fusion_layer = nn.Linear(combined_dim + transformer_d_model * 2, combined_dim // 2)
        self.predictor = nn.Sequential(
            nn.Linear(combined_dim // 2, combined_dim // 4),
            nn.ReLU(),
            nn.Dropout(0.4),
            nn.Linear(combined_dim // 4, 1)
        )

    def forward(self, drug_data, protein_data):
        # 处理药物数据
        if isinstance(drug_data, Data) and not isinstance(drug_data, Batch):
            drug_x = drug_data.x
            drug_edge_index = drug_data.edge_index
            drug_batch = torch.zeros(drug_data.x.size(0), dtype=torch.long, device=drug_data.x.device)
        else:
            drug_x = drug_data.x
            drug_edge_index = drug_data.edge_index
            drug_batch = drug_data.batch

        # 药物特征提取
        drug_repr = self.drug_encoder(drug_x, drug_edge_index, drug_batch)

        # 蛋白特征提取
        protein_repr = self.protein_encoder(protein_data)

        # 投影到 Transformer 输入维度
        drug_repr = self.drug_projection(drug_repr)
        protein_repr = self.protein_projection(protein_repr)

        # 构造 Transformer 输入
        batch_size = protein_repr.size(0)
        transformer_input = torch.stack([drug_repr, protein_repr], dim=1)  # [batch_size, seq_len=2, transformer_d_model]

        # 实数分支：Transformer 编码
        transformer_output = self.transformer(transformer_input)  # [batch_size, seq_len=2, transformer_d_model]
        real_features = transformer_output.view(batch_size, -1)  # [batch_size, transformer_d_model * 2]

        # 虚数分支：构造复数表示
        complex_input = torch.stack([transformer_input, torch.zeros_like(transformer_input)], dim=-1)  # [batch_size, seq_len=2, transformer_d_model, 2]
        complex_input = complex_input.view(batch_size * 2, transformer_input.size(-1), 2)  # [batch_size * seq_len, transformer_d_model, 2]
        complex_features = self.complex_branch1(complex_input)
        complex_features = self.complex_act(complex_features)
        complex_features = self.complex_branch2(complex_features)
        complex_features = self.complex_act(complex_features)
        complex_features = self.complex_branch3(complex_features)
        complex_features = self.complex_act(complex_features)
        complex_magnitude = torch.sqrt(complex_features[:, :, 0]**2 + complex_features[:, :, 1]**2)  # [batch_size * seq_len, transformer_d_model]
        complex_magnitude = complex_magnitude.view(batch_size, -1)  # [batch_size, transformer_d_model * 2]

        # 特征融合：使用注意力机制
        real_features_ = real_features.view(batch_size, 1, -1)  # [batch_size, 1, transformer_d_model * 2]
        complex_magnitude_ = complex_magnitude.view(batch_size, 1, -1)  # [batch_size, 1, transformer_d_model * 2]
        # 调整维度以匹配 MultiheadAttention 的 embed_dim
        real_features_ = self.attention_projection(real_features_)  # [batch_size, 1, transformer_d_model]
        complex_magnitude_ = self.attention_projection(complex_magnitude_)  # [batch_size, 1, transformer_d_model]
        fused_features, _ = self.attention(real_features_, complex_magnitude_, complex_magnitude_)
        fused_features = fused_features.squeeze(1)  # [batch_size, transformer_d_model]
        fused_features = torch.cat([real_features, complex_magnitude], dim=-1)  # [batch_size, transformer_d_model * 4]
        fused_features = self.fusion_layer(fused_features)  # [batch_size, transformer_d_model]
        fused_features = torch.relu(fused_features)

        # 预测
        interaction = self.predictor(fused_features)
        return interaction

    def predict_interaction(self, drug_data, protein_data):
        """预测药物-靶点相互作用"""
        self.eval()
        with torch.no_grad():
            return self.forward(drug_data, protein_data)