# 保存为 E:\AI\drug_discovery_project\scripts\calculate_sample_ratio.py
import torch
import os

# 设置数据路径
interactions_dir = "E:/AI/drug_discovery_project/data/processed/interactions"

# 加载数据
interactions_path = os.path.join(interactions_dir, 'interactions.pt')
train_idx_path = os.path.join(interactions_dir, 'train_idx.pt')
val_idx_path = os.path.join(interactions_dir, 'val_idx.pt')
test_idx_path = os.path.join(interactions_dir, 'test_idx.pt')

# 加载 interactions 和索引
interactions = torch.load(interactions_path)
train_idx = torch.load(train_idx_path)
val_idx = torch.load(val_idx_path)
test_idx = torch.load(test_idx_path)

# 转换为 numpy 数组（如果需要）
if isinstance(train_idx, torch.Tensor):
    train_idx = train_idx.cpu().numpy()
if isinstance(val_idx, torch.Tensor):
    val_idx = val_idx.cpu().numpy()
if isinstance(test_idx, torch.Tensor):
    test_idx = test_idx.cpu().numpy()
if isinstance(interactions, torch.Tensor):
    interactions = interactions.cpu().numpy()

# 计算正负样本比例
def calculate_ratio(labels, dataset_name):
    total_samples = len(labels)
    positive_samples = int(sum(labels))
    negative_samples = total_samples - positive_samples
    positive_ratio = positive_samples / total_samples
    negative_ratio = negative_samples / total_samples
    print(f"{dataset_name} Set:")
    print(f"Total samples: {total_samples}")
    print(f"Positive samples: {positive_samples} ({positive_ratio:.4f})")
    print(f"Negative samples: {negative_samples} ({negative_ratio:.4f})")
    print("------")

# 计算训练集、验证集和测试集的正负样本比例
train_labels = interactions[train_idx]
val_labels = interactions[val_idx]
test_labels = interactions[test_idx]

calculate_ratio(train_labels, "Training")
calculate_ratio(val_labels, "Validation")
calculate_ratio(test_labels, "Test")