#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
创建项目所需的目录结构并确保路径分隔符正确
"""

import os
import sys

def normalize_path(path):
    """标准化路径，处理不同操作系统的路径分隔符"""
    return os.path.normpath(path)

def create_directories():
    """创建所有必要的目录"""
    # 基本目录
    base_dirs = [
        "data",
        "configs",
        "logs",
        "models",
        "runs",
        "scripts"
    ]
    
    # 数据相关目录
    data_dirs = [
        os.path.join("data", "raw"),
        os.path.join("data", "raw", "drugbank"),
        os.path.join("data", "processed"),
        os.path.join("data", "processed", "features"),
        os.path.join("data", "processed", "interactions")
    ]
    
    # 日志相关目录
    log_dirs = [
        os.path.join("logs", "train"),
        os.path.join("logs", "eval")
    ]
    
    # 创建所有目录
    all_dirs = base_dirs + data_dirs + log_dirs
    
    for directory in all_dirs:
        dir_path = normalize_path(directory)
        if not os.path.exists(dir_path):
            os.makedirs(dir_path, exist_ok=True)
            print(f"创建目录: {dir_path}")
        else:
            print(f"目录已存在: {dir_path}")
    
    print("\n目录结构创建完成！")

def verify_paths():
    """验证路径配置是否正确"""
    # 检查关键路径
    required_paths = [
        os.path.join("data", "processed", "interactions"),
        os.path.join("data", "processed", "features"),
        os.path.join("configs")
    ]
    
    for path in required_paths:
        path = normalize_path(path)
        if not os.path.exists(path):
            print(f"错误: 路径 {path} 不存在")
            return False
    
    print("\n路径验证通过！")
    return True

def print_instructions():
    """打印使用说明"""
    print("\n使用说明:")
    print("1. 请将分子性质数据文件放置在 data/raw/molecular_properties.csv")
    print("2. 请将药物-靶点相互作用数据文件放置在 data/raw/drugbank/drug_target_interactions.csv")
    print("3. 运行数据处理脚本: python src/process_drug_target_interactions.py")
    print("4. 运行训练脚本: python src/train_dti.py")
    print("5. 或者使用一键运行脚本: python start.py")

def print_path_debug():
    """打印路径调试信息"""
    print("\n路径调试信息:")
    print(f"当前工作目录: {os.getcwd()}")
    print(f"Python 路径分隔符: {os.sep}")
    print(f"操作系统: {sys.platform}")
    
    # 检查 Windows 特有的路径问题
    if sys.platform.startswith('win'):
        print("\nWindows 系统路径检查:")
        test_path = os.path.join("data", "processed", "interactions", "drug_graphs.pt")
        norm_path = normalize_path(test_path)
        print(f"测试路径: {test_path}")
        print(f"标准化路径: {norm_path}")
        print(f"路径存在: {os.path.exists(norm_path)}")

def main():
    """主函数"""
    print("=" * 80)
    print("创建药物-靶点相互作用预测项目目录结构")
    print("=" * 80)
    
    create_directories()
    verify_paths()
    print_path_debug()
    print_instructions()
    
    print("\n脚本完成！")

if __name__ == "__main__":
    main() 