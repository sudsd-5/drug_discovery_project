import os
import sys
import yaml
import pkg_resources
import torch
import logging
from rdkit import Chem
import MDAnalysis as mda

def setup_logging():
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler('environment_check.log'),
            logging.StreamHandler()
        ]
    )

def load_config(config_path):
    with open(config_path, 'r') as f:
        return yaml.safe_load(f)

def check_python_version():
    required_version = "3.8"
    current_version = sys.version.split()[0]
    if current_version < required_version:
        logging.error(f"Python版本不满足要求: 需要 {required_version}+, 当前 {current_version}")
        return False
    logging.info(f"Python版本检查通过: {current_version}")
    return True

def check_cuda():
    if not torch.cuda.is_available():
        logging.error("CUDA不可用")
        return False
    
    cuda_version = torch.version.cuda
    logging.info(f"CUDA版本: {cuda_version}")
    return True

def check_gpu_memory():
    if torch.cuda.is_available():
        gpu_memory = torch.cuda.get_device_properties(0).total_memory / 1024**3  # 转换为GB
        logging.info(f"GPU显存: {gpu_memory:.2f}GB")
        return gpu_memory >= 8
    return False

def check_dependencies(config):
    missing_packages = []
    version_mismatches = []
    
    for package, version in config['dependencies'].items():
        try:
            installed_version = pkg_resources.get_distribution(package).version
            if installed_version < version:
                version_mismatches.append(f"{package}: 需要 {version}, 当前 {installed_version}")
        except pkg_resources.DistributionNotFound:
            missing_packages.append(package)
    
    if missing_packages:
        logging.error(f"缺少依赖包: {', '.join(missing_packages)}")
        return False
    
    if version_mismatches:
        logging.error(f"版本不匹配:\n" + "\n".join(version_mismatches))
        return False
    
    logging.info("所有依赖包检查通过")
    return True

def check_rdkit():
    try:
        mol = Chem.MolFromSmiles("CC")
        if mol is None:
            logging.error("RDKit无法处理SMILES")
            return False
        logging.info("RDKit检查通过")
        return True
    except Exception as e:
        logging.error(f"RDKit检查失败: {str(e)}")
        return False

def check_mdanalysis():
    try:
        # 创建一个简单的测试文件
        with open("test.pdb", "w") as f:
            f.write("ATOM      1  N   ALA     1      27.834  24.516  23.700  1.00  0.00           N\n")
            f.write("ATOM      2  CA  ALA     1      26.581  25.234  23.700  1.00  0.00           C\n")
        
        u = mda.Universe("test.pdb")
        os.remove("test.pdb")
        logging.info("MDAnalysis检查通过")
        return True
    except Exception as e:
        logging.error(f"MDAnalysis检查失败: {str(e)}")
        return False

def check_directories(config):
    missing_dirs = []
    for dir_path in config['project_structure']['data']['raw'].values():
        if not os.path.exists(dir_path):
            missing_dirs.append(dir_path)
    
    if missing_dirs:
        logging.error(f"缺少目录: {', '.join(missing_dirs)}")
        return False
    
    logging.info("目录结构检查通过")
    return True

def main():
    setup_logging()
    logging.info("开始环境检查...")
    
    # 加载配置
    config = load_config("configs/environment.yaml")
    
    # 运行检查
    checks = [
        ("Python版本", check_python_version),
        ("CUDA", check_cuda),
        ("GPU显存", check_gpu_memory),
        ("依赖包", lambda: check_dependencies(config)),
        ("RDKit", check_rdkit),
        ("MDAnalysis", check_mdanalysis),
        ("目录结构", lambda: check_directories(config))
    ]
    
    all_passed = True
    for check_name, check_func in checks:
        logging.info(f"\n检查 {check_name}...")
        if not check_func():
            all_passed = False
            logging.error(f"{check_name}检查失败")
    
    if all_passed:
        logging.info("\n所有环境检查通过！")
    else:
        logging.error("\n环境检查失败，请查看日志了解详细信息。")
        sys.exit(1)

if __name__ == "__main__":
    main() 