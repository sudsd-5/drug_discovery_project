import os
print(f"CPU 核心数: {os.cpu_count()}")