#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
运行药物-靶点相互作用预测的完整流程
包括数据预处理、模型训练和评估
"""

import os
import argparse
import subprocess
import time
import yaml


def load_config(config_path='configs/dti_config.yaml'):
    """加载配置文件"""
    config_path = os.path.normpath(config_path)
    with open(config_path, 'r', encoding='utf-8') as f:
        return yaml.safe_load(f)


def run_command(command, description=None):
    """运行命令并打印输出"""
    if description:
        print(f"\n{'-' * 80}\n{description}\n{'-' * 80}")
    
    print(f"执行命令: {command}")
    start_time = time.time()
    process = subprocess.Popen(
        command, 
        shell=True, 
        stdout=subprocess.PIPE, 
        stderr=subprocess.STDOUT,
        text=True
    )
    
    # 实时打印输出
    for line in process.stdout:
        print(line.strip())
    
    process.wait()
    end_time = time.time()
    
    if process.returncode == 0:
        print(f"命令成功完成! 耗时: {end_time - start_time:.2f} 秒")
        return True
    else:
        print(f"命令失败，退出代码: {process.returncode}")
        return False


def ensure_directories(config):
    """确保所有必要的目录都存在"""
    directories = [
        os.path.join('data', 'raw'),
        os.path.join('data', 'processed', 'features'),
        os.path.join('data', 'processed', 'interactions'),
        config['logging']['log_dir'],
        config['logging']['save_model_dir'],
        config['logging']['tensorboard_dir']
    ]
    
    for directory in directories:
        directory = os.path.normpath(directory)
        os.makedirs(directory, exist_ok=True)
        print(f"目录已确保存在: {directory}")


def process_data(args):
    """处理数据"""
    print("\n开始数据处理阶段...")
    
    # 处理药物-靶点相互作用数据
    command = "python src/process_drug_target_interactions.py"
    if not run_command(command, "处理药物-靶点相互作用数据"):
        # 如果命令行运行失败，尝试直接导入模块运行
        print("尝试直接导入模块运行...")
        try:
            import src.process_drug_target_interactions as processor
            processor.process_drug_target_interactions("data/raw/drugbank/drug_target_interactions.csv")
            processor.process_molecular_properties("data/raw/molecular_properties.csv")
            print("数据处理成功完成！")
            return True
        except Exception as e:
            print(f"数据处理失败: {e}")
            return False
    
    print("数据处理完成!")
    return True


def train_model(args):
    """训练模型"""
    print("\n开始模型训练阶段...")
    
    # 训练药物-靶点相互作用预测模型
    command = f"python src/train_dti.py"
    if not run_command(command, "训练药物-靶点相互作用预测模型"):
        return False
    
    print("模型训练完成!")
    return True


def evaluate_model(args):
    """评估模型"""
    print("\n开始模型评估阶段...")
    
    # 评估药物-靶点相互作用预测模型
    # 这个功能已经集成在 train_dti.py 中
    print("模型评估已在训练脚本中完成!")
    return True


def run_pipeline(args):
    """运行完整的药物-靶点相互作用预测流程"""
    config = load_config(args.config)
    print(f"加载配置文件: {args.config}")
    
    # 确保所有目录存在
    ensure_directories(config)
    
    # 运行数据处理
    if args.process_data:
        
        if not process_data(args):
            print("数据处理失败，停止流程")
            return
    
    # 运行模型训练
    if args.train:
        if not train_model(args):
            print("模型训练失败，停止流程")
            return
    
    # 运行模型评估
    if args.evaluate:
        if not evaluate_model(args):
            print("模型评估失败，停止流程")
            return
    
    print("\n药物-靶点相互作用预测流程完成!")


def parse_arguments():
    """解析命令行参数"""
    parser = argparse.ArgumentParser(
        description="药物-靶点相互作用预测流程"
    )
    
    parser.add_argument(
        "--config", 
        type=str, 
        default="configs/dti_config.yaml",
        help="配置文件路径"
    )
    
    parser.add_argument(
        "--process_data", 
        action="store_true",
        help="运行数据处理阶段"
    )
    
    parser.add_argument(
        "--train", 
        action="store_true",
        help="运行模型训练阶段"
    )
    
    parser.add_argument(
        "--evaluate", 
        action="store_true",
        help="运行模型评估阶段"
    )
    
    parser.add_argument(
        "--all", 
        action="store_true",
        help="运行完整流程（数据处理、训练和评估）"
    )
    
    args = parser.parse_args()
    
    # 如果指定了 --all，则运行所有阶段
    if args.all:
        args.process_data = args.train = args.evaluate = True
    
    # 如果没有指定任何阶段，则默认运行所有阶段
    if not (args.process_data or args.train or args.evaluate):
        args.process_data = args.train = args.evaluate = True
    
    return args


if __name__ == "__main__":
    args = parse_arguments()
    run_pipeline(args) 